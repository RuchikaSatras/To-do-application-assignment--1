import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EmpAddEditComponent } from './emp-add-edit/emp-add-edit.component';
import { EmployeeService } from './services/employee.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService } from './core/core.service';
import { SelectionModel } from '@angular/cdk/collections';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = [
    'select',
    'assignedto',
    'status',
 
    'duetodate',
    
    'priority',
    'description',
    
    'action',
  ];

  dataSource!: MatTableDataSource<any>;
  selection = new SelectionModel<any>(true, []);
  // dataSource = new MatTableDataSource<any>([]);


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild('input') inputElement!: ElementRef;

  pageSize = 10;
  currentPage = 0;
  dataLoaded = false;

  constructor(
    private _dialog: MatDialog,
    private _empService: EmployeeService,
    private _coreService: CoreService

  ) { }

  ngOnInit(): void {
    this.getEmployeeList();
  }

  ngAfterViewInit() {
    
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }
  openAddEditEmpForm() {
    const dialogRef = this._dialog.open(EmpAddEditComponent);
    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getEmployeeList();
        }
      },
    });
  }


 getEmployeeList() {
  this._empService.getEmployeeList().subscribe({
    next: (res) => {
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    },
    error: console.error
  });
} 

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }




  deleteEmployee(id: number) { this._empService.deleteEmployee(id).subscribe({ next: () => this.getEmployeeList(), error: console.log }); }
  openEditForm(data: any) {
    const dialogRef = this._dialog.open(EmpAddEditComponent, {
      data,
    });

    dialogRef.afterClosed().subscribe({
      next: (val) => {
        if (val) {
          this.getEmployeeList();
        }
      },
    });
  }
  
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource ? this.dataSource.data.length : 0;
    return numSelected === numRows;
  }

  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    if (this.dataSource) {
      this.selection.select(...this.dataSource.data);
    }
  }

  refresh() {
    this.getEmployeeList();
  
    if (this.dataSource) {
      this.dataSource.filter = '';
    }
    if (this.inputElement) {
      this.inputElement.nativeElement.value = '';
    }
  }

 
  isAnySelected(): boolean {
    return this.selection.selected.length > 0;
  }
 
deleteSelectedEmployees() {
  const selectedIds = this.selection.selected.map(item => item.id);
  if (!selectedIds.length) return;

  if (confirm(`Are you sure you want to delete ${selectedIds.length} items?`)) {
    let completed = 0;
    selectedIds.forEach(id => {
      this._empService.deleteEmployee(id).subscribe({
        next: () => {
          completed++;
          if (completed === selectedIds.length) {
            this._coreService.openSnackBar('Selected employees deleted!');
            this.selection.clear();
            this.getEmployeeList();
          }
        },
        error: (err) => console.error(err)
      });
    });
  }
}

  getSelectedEmployeeForEdit(): any | null {
    if (this.selection.selected.length === 1) {
      return this.selection.selected[0];
    }
    return null;
  }

openSelectedEditForm() {
  const selectedItem = this.getSelectedEmployeeForEdit();
  if (selectedItem) this.openEditForm(selectedItem);
}
}

