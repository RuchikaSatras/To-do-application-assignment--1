import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CoreService } from '../core/core.service';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-emp-add-edit',
  templateUrl: './emp-add-edit.component.html',
  styleUrls: ['./emp-add-edit.component.scss'],
})
export class EmpAddEditComponent implements OnInit {

  empForm!: FormGroup;

  description: string[] = [];

  constructor(
    private _fb: FormBuilder,
    private _empService: EmployeeService,
    private _dialogRef: MatDialogRef<EmpAddEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _coreService: CoreService
  ) { 
    this.empForm = this._fb.group({
      assignedto: ['', Validators.required],
      status: ['', Validators.required],
      duetodate: ['', Validators.required],
      priority: ['', Validators.required],
      description: [''],
    });
  }

  ngOnInit(): void {
    //this.empForm.patchValue(this.data);
    if (this.data) {
      const formattedData = {
        ...this.data,
        duetodate: this.data.duetodate ? new Date(this.data.duetodate) : ''
      };

      this.empForm.patchValue(formattedData);
      console.log("Data received:", this.data);
      console.log("Form after patch:", this.empForm.value);
    }
  }

 

onFormSubmit() {
  if (this.empForm.invalid) {
    this.empForm.markAllAsTouched();
    return;
  }

  if (this.data) {
    // Update existing
    this._empService.updateEmployee(this.data.id, this.empForm.value).subscribe({
      next: () => {
        this._coreService.openSnackBar('Employee updated!');
        this._dialogRef.close(true);
      },
      error: (err) => console.error(err),
    });
  } else {
    // Add new
    this._empService.addEmployee(this.empForm.value).subscribe({
      next: () => {
        this._coreService.openSnackBar('Employee added successfully');
        this._dialogRef.close(true);
      },
      error: (err) => console.error(err),
    });
  }
}


}


